function cookie(name, value, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

export async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "method" };

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch {}
  const pass = String(body.pass || "");

  const ownerPass = process.env.OWNER_PASS || "";
  if (!ownerPass || pass !== ownerPass) return { statusCode: 403, body: "bad_pass" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return { statusCode: 500, body: "server_not_configured" };

  const ownerSession = crypto.randomUUID() + "." + crypto.randomUUID();
  const ttl = 60 * 60 * 24 * 30; // 30 дней

  await fetch(
    `${url}/set/${encodeURIComponent("owner:" + ownerSession)}/${encodeURIComponent("1")}?EX=${ttl}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  return {
    statusCode: 200,
    headers: {
      "Set-Cookie": cookie("owner_session", ownerSession, ttl),
      "Content-Type": "application/json; charset=utf-8",
    },
    body: JSON.stringify({ ok: true }),
  };
}
