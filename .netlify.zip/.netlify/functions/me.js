function getCookie(headers, name) {
  const c = headers.cookie || "";
  return c.split(";").map(v => v.trim()).find(v => v.startsWith(name + "="))?.slice((name + "=").length) || "";
}

export async function handler(event) {
  const adminSession = getCookie(event.headers, "admin_session");
  if (!adminSession) return { statusCode: 401, body: "no" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return { statusCode: 500, body: "server_not_configured" };

  const r = await fetch(`${url}/get/${encodeURIComponent("admin_session:" + adminSession)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const d = await r.json();
  if (!d?.result) return { statusCode: 401, body: "no" };

  let meta = null;
  try { meta = JSON.parse(d.result); } catch {}

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ ok: true, login: meta?.login || "admin" }),
  };
}
