function getCookie(headers, name) {
  const c = headers.cookie || "";
  return c.split(";").map(v => v.trim()).find(v => v.startsWith(name + "="))?.slice((name + "=").length) || "";
}

export async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "method" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return { statusCode: 500, body: "server_not_configured" };

  const adminSession = getCookie(event.headers, "admin_session");
  if (!adminSession) return { statusCode: 403, body: "admin_only" };

  const ar = await fetch(`${url}/get/${encodeURIComponent("admin_session:" + adminSession)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const ad = await ar.json();
  if (!ad?.result) return { statusCode: 403, body: "admin_only" };

  let adminMeta = null;
  try { adminMeta = JSON.parse(ad.result); } catch {}
  const adminLogin = String(adminMeta?.login || "admin").slice(0, 32);

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch {}

  const name = String(body.name || "User").slice(0, 40);

  let sessTtl = parseInt(body.ttl, 10);
  if (!Number.isFinite(sessTtl)) sessTtl = 60 * 60 * 24 * 30;

  if (sessTtl !== 0) {
    const min = 60 * 60 * 24;
    const max = 60 * 60 * 24 * 365;
    sessTtl = Math.max(min, Math.min(sessTtl, max));
  }

  const code = String(Math.floor(100000 + Math.random() * 900000));
  const inviteTtl = 300;

  const payload = JSON.stringify({
    name,
    ttl: sessTtl,
    issuedBy: adminLogin,
    issuedAt: Date.now(),
  });

  await fetch(
    `${url}/set/${encodeURIComponent("invite:" + code)}/${encodeURIComponent(payload)}?EX=${inviteTtl}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  await fetch(`${url}/incr/${encodeURIComponent("stat:" + adminLogin + ":total")}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  await fetch(`${url}/incr/${encodeURIComponent("stat:" + adminLogin + ":ttl:" + String(sessTtl))}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ code, ttl_seconds: inviteTtl, name, session_ttl: sessTtl, issuedBy: adminLogin }),
  };
   // ---------- OWNER STATS / EVENTS ----------
  // Пытаемся достать admin username из admin:<adminSession>
  let adminUser = "unknown";
  if (adminSession) {
    try {
      const rr = await fetch(`${url}/get/${encodeURIComponent("admin:" + adminSession)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const dd = await rr.json();
      if (dd?.result) {
        // если там JSON: {"user":"admin1"} - вытащим
        try {
          const j = JSON.parse(dd.result);
          if (j?.user) adminUser = String(j.user).slice(0, 40);
        } catch {
          // если там просто "1"
          adminUser = "admin";
        }
      }
    } catch {}
  }

  // 1) обновляем агрегированную статистику owner:stats
  const statsKey = "owner:stats";
  const sr = await fetch(`${url}/get/${encodeURIComponent(statsKey)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const sd = await sr.json();
  let stats = {};
  try { stats = JSON.parse(sd?.result || "{}"); } catch { stats = {}; }

  stats.totalIssued = (stats.totalIssued || 0) + 1;
  stats.lastEventAt = Date.now();
  stats.admins = Array.isArray(stats.admins) ? stats.admins : [];

  let a = stats.admins.find(x => x.admin === adminUser);
  if (!a) {
    a = { admin: adminUser, total: 0, byTtl: {}, lastAt: 0 };
    stats.admins.push(a);
  }
  a.total = (a.total || 0) + 1;
  a.byTtl = a.byTtl || {};
  a.byTtl[String(sessTtl)] = (a.byTtl[String(sessTtl)] || 0) + 1;
  a.lastAt = Date.now();

  await fetch(
    `${url}/set/${encodeURIComponent(statsKey)}/${encodeURIComponent(JSON.stringify(stats))}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  // 2) пишем лог событий owner:events (храним массив последних 200)
  const eventsKey = "owner:events";
  const er = await fetch(`${url}/get/${encodeURIComponent(eventsKey)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const ed = await er.json();
  let events = [];
  try { events = JSON.parse(ed?.result || "[]"); } catch { events = []; }
  if (!Array.isArray(events)) events = [];

  events.unshift({
    at: Date.now(),
    admin: adminUser,
    name,
    sessTtl,
    code
  });
  events = events.slice(0, 200);

  await fetch(
    `${url}/set/${encodeURIComponent(eventsKey)}/${encodeURIComponent(JSON.stringify(events))}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
}
