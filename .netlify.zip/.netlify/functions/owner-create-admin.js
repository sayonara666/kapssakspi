async function sha256Hex(str) {
  const enc = new TextEncoder().encode(str);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function getCookie(headers, name) {
  const c = headers.cookie || "";
  return c.split(";").map(v => v.trim()).find(v => v.startsWith(name + "="))?.slice((name + "=").length) || "";
}

export async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "method" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  const pepper = process.env.ADMIN_PEPPER || "";
  if (!url || !token || !pepper) return { statusCode: 500, body: "server_not_configured" };

  const ownerSession = getCookie(event.headers, "owner_session");
  if (!ownerSession) return { statusCode: 401, body: "owner_only" };

  const ok = await fetch(`${url}/get/${encodeURIComponent("owner_session:" + ownerSession)}`, {
    headers: { Authorization: `Bearer ${token}` },
  }).then(r => r.json()).catch(() => null);

  if (!ok?.result) return { statusCode: 401, body: "owner_only" };

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch {}

  const login = String(body.login || "").trim().toLowerCase().slice(0, 32);
  const pass = String(body.pass || "");

  if (!/^[a-z0-9._-]{3,32}$/.test(login)) return { statusCode: 400, body: "bad_login" };
  if (pass.length < 6) return { statusCode: 400, body: "bad_pass_len" };

  const salt = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
  const hash = await sha256Hex(`${pepper}:${salt}:${pass}`);

  const adminObj = {
    login,
    salt,
    hash,
    enabled: true,
    createdAt: Date.now(),
  };

  await fetch(
    `${url}/set/${encodeURIComponent("admin_user:" + login)}/${encodeURIComponent(JSON.stringify(adminObj))}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  // admins_list (массив) для owner панели
  try {
    const gr = await fetch(`${url}/get/${encodeURIComponent("admins_list")}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const gd = await gr.json();
    let arr = [];
    try { arr = gd?.result ? JSON.parse(gd.result) : []; } catch { arr = []; }
    if (!Array.isArray(arr)) arr = [];
    if (!arr.includes(login)) {
      arr.push(login);
      await fetch(`${url}/set/${encodeURIComponent("admins_list")}/${encodeURIComponent(JSON.stringify(arr))}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
    }
  } catch {}

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ ok: true, login }),
  };
}
