function getCookie(headers, name) {
  const c = headers.cookie || "";
  return c.split(";").map(v => v.trim()).find(v => v.startsWith(name + "="))?.slice((name + "=").length) || "";
}

async function getKey(url, token, key) {
  const r = await fetch(`${url}/get/${encodeURIComponent(key)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const d = await r.json();
  return d?.result ?? null;
}

export async function handler(event) {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return { statusCode: 500, body: "server_not_configured" };

  const ownerSession = getCookie(event.headers, "owner_session");
  if (!ownerSession) return { statusCode: 401, body: "owner_only" };

  const ok = await getKey(url, token, "owner_session:" + ownerSession);
  if (!ok) return { statusCode: 401, body: "owner_only" };

  let admins = [];
  try {
    const raw = await getKey(url, token, "admins_list");
    admins = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(admins)) admins = [];
  } catch { admins = []; }

  const list = [];
  for (const login of admins) {
    const rec = await getKey(url, token, "admin_user:" + login);
    if (!rec) continue;
    try {
      const obj = JSON.parse(rec);
      list.push({ login: obj.login, enabled: !!obj.enabled, createdAt: obj.createdAt });
    } catch {}
  }

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ ok: true, admins: list }),
  };
}
