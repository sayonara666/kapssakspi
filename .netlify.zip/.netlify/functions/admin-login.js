function cookie(name, value, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

async function sha256Hex(str) {
  const enc = new TextEncoder().encode(str);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "method" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  const pepper = process.env.ADMIN_PEPPER || "";
  if (!url || !token || !pepper) return { statusCode: 500, body: "server_not_configured" };

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch {}

  const login = String(body.login || "").trim().toLowerCase().slice(0, 32);
  const pass = String(body.pass || "");

  if (!/^[a-z0-9._-]{3,32}$/.test(login)) return { statusCode: 400, body: "bad_login" };
  if (!pass) return { statusCode: 400, body: "bad_pass" };

  const gr = await fetch(`${url}/get/${encodeURIComponent("admin_user:" + login)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const gd = await gr.json();
  if (!gd?.result) return { statusCode: 403, body: "bad_login_or_pass" };

  let adminObj = null;
  try { adminObj = JSON.parse(gd.result); } catch {}
  if (!adminObj?.salt || !adminObj?.hash) return { statusCode: 403, body: "bad_login_or_pass" };
  if (!adminObj.enabled) return { statusCode: 403, body: "admin_disabled" };

  const calc = await sha256Hex(`${pepper}:${adminObj.salt}:${pass}`);
  if (calc !== adminObj.hash) return { statusCode: 403, body: "bad_login_or_pass" };

  const adminSession = crypto.randomUUID() + "." + crypto.randomUUID();
  const ttl = 60 * 60 * 24 * 30;

  const meta = JSON.stringify({ login, createdAt: Date.now() });

  await fetch(
    `${url}/set/${encodeURIComponent("admin_session:" + adminSession)}/${encodeURIComponent(meta)}?EX=${ttl}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  return {
    statusCode: 200,
    headers: {
      "Set-Cookie": cookie("admin_session", adminSession, ttl),
      "Content-Type": "application/json; charset=utf-8",
    },
    body: JSON.stringify({ ok: true, login }),
  };
}
