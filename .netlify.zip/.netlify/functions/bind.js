function cookie(name, value, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

function pickIp(headers) {
  return (
    headers["x-nf-client-connection-ip"] ||
    (headers["x-forwarded-for"] ? String(headers["x-forwarded-for"]).split(",")[0].trim() : "") ||
    headers["client-ip"] ||
    ""
  );
}

export async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "method" };

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch {}
  const code = String(body.code || "").trim();
  if (!/^\d{6}$/.test(code)) return { statusCode: 400, body: "bad_code" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return { statusCode: 500, body: "server_not_configured" };

  try {
    const gr = await fetch(`${url}/getdel/${encodeURIComponent("invite:" + code)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const gd = await gr.json();
    if (!gd || gd.result == null) return { statusCode: 403, body: "invite_invalid_or_expired" };

    let invite = null;
    try { invite = JSON.parse(gd.result); } catch {}
    if (!invite?.name || invite.ttl === undefined || invite.ttl === null) {
      return { statusCode: 403, body: "invite_invalid_or_expired" };
    }

    const name = String(invite.name).slice(0, 40);
    const issuedBy = String(invite.issuedBy || "admin").slice(0, 32);

    let ttl = Number(invite.ttl);
    if (!Number.isFinite(ttl)) ttl = 60 * 60 * 24 * 30;

    if (ttl !== 0) {
      const min = 60 * 60 * 24;
      const max = 60 * 60 * 24 * 365;
      ttl = Math.max(min, Math.min(ttl, max));
    }

    // old session cleanup
    const uget = await fetch(`${url}/get/${encodeURIComponent("user:" + name)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const ujd = await uget.json();
    const oldSession = ujd?.result;

    if (oldSession) {
      await fetch(`${url}/del/${encodeURIComponent("sess:" + oldSession)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetch(`${url}/del/${encodeURIComponent("user:" + name)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
    }

    const session = crypto.randomUUID() + "." + crypto.randomUUID();

    const h = event.headers || {};
    const meta = {
      name,
      createdAt: Date.now(),
      lastSeen: Date.now(),
      issuedBy,
      issuedAt: Number(invite.issuedAt || Date.now()),
      ua: h["user-agent"] || "",
      lang: h["accept-language"] || "",
      ip: pickIp(h),
      forever: ttl === 0
    };

    const metaStr = JSON.stringify(meta);
    const cookieMaxAge = ttl === 0 ? 60 * 60 * 24 * 365 * 5 : ttl;

    if (ttl === 0) {
      await fetch(`${url}/set/${encodeURIComponent("sess:" + session)}/${encodeURIComponent(metaStr)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetch(`${url}/set/${encodeURIComponent("user:" + name)}/${encodeURIComponent(session)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
    } else {
      await fetch(`${url}/set/${encodeURIComponent("sess:" + session)}/${encodeURIComponent(metaStr)}?EX=${ttl}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetch(`${url}/set/${encodeURIComponent("user:" + name)}/${encodeURIComponent(session)}?EX=${ttl}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
    }

    return {
      statusCode: 200,
      headers: {
        "Set-Cookie": cookie("session", session, cookieMaxAge),
        "Content-Type": "application/json; charset=utf-8",
      },
      body: JSON.stringify({ ok: true, name, ttl, forever: ttl === 0 }),
    };
  } catch {
    return { statusCode: 502, body: "upstash_error" };
  }
}
