function getCookie(headers, name) {
  const c = headers.cookie || "";
  return c.split(";").map(v => v.trim()).find(v => v.startsWith(name + "="))?.slice((name + "=").length) || "";
}

export async function handler(event) {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "method" };

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return { statusCode: 500, body: "server_not_configured" };

  const ownerSession = getCookie(event.headers, "owner_session");
  if (!ownerSession) return { statusCode: 401, body: "owner_only" };

  const ok = await fetch(`${url}/get/${encodeURIComponent("owner_session:" + ownerSession)}`, {
    headers: { Authorization: `Bearer ${token}` },
  }).then(r => r.json()).catch(() => null);

  if (!ok?.result) return { statusCode: 401, body: "owner_only" };

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch {}

  const login = String(body.login || "").trim().toLowerCase().slice(0, 32);
  const enabled = !!body.enabled;

  const gr = await fetch(`${url}/get/${encodeURIComponent("admin_user:" + login)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const gd = await gr.json();
  if (!gd?.result) return { statusCode: 404, body: "not_found" };

  let adminObj;
  try { adminObj = JSON.parse(gd.result); } catch { adminObj = null; }
  if (!adminObj) return { statusCode: 500, body: "bad_admin_record" };

  adminObj.enabled = enabled;

  await fetch(
    `${url}/set/${encodeURIComponent("admin_user:" + login)}/${encodeURIComponent(JSON.stringify(adminObj))}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ ok: true, login, enabled }),
  };
}
