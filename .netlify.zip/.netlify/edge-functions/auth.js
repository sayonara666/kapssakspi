export default async (request, context) => {
  const url = new URL(request.url);
  const path = url.pathname;

  // Разрешаем страницы и функции без проверки сессии
if (
  path === "/bind.html" ||
  path === "/admin.html" ||
  path === "/owner.html" ||      // <-- добавь
  path.startsWith("/.netlify/functions/")
) {
  return context.next();
}

  // Парсим cookie session
  const cookieHeader = request.headers.get("cookie") || "";
  const sessionRaw = cookieHeader
    .split(";")
    .map((v) => v.trim())
    .find((v) => v.startsWith("session="))
    ?.slice("session=".length);

  if (!sessionRaw) {
    return Response.redirect(new URL("/bind.html", request.url), 302);
  }

  const session = decodeURIComponent(sessionRaw);

  const redisUrl = Netlify.env.get("UPSTASH_REDIS_REST_URL");
  const redisToken = Netlify.env.get("UPSTASH_REDIS_REST_TOKEN");

  if (!redisUrl || !redisToken) {
    return Response.redirect(new URL("/bind.html", request.url), 302);
  }

  const key = "sess:" + session;

  try {
    // 1) Проверяем сессию + достаём meta JSON
    const r = await fetch(`${redisUrl}/get/${encodeURIComponent(key)}`, {
      headers: { Authorization: `Bearer ${redisToken}` },
    });

    const data = await r.json();

    if (!data || data.result == null) {
      return Response.redirect(new URL("/bind.html", request.url), 302);
    }

    // 2) Обновляем lastSeen (и можно обновлять некоторые поля)
    // Важно: не ломаем доступ если JSON битый.
    try {
      const meta = JSON.parse(data.result);
      meta.lastSeen = Date.now();

      // по желанию: обновлять язык/гео каждый раз (обычно норм)
      // meta.lang = request.headers.get("accept-language") || meta.lang;

      const metaStr = JSON.stringify(meta);

      if (meta.forever) {
        // "навсегда": без EX
        await fetch(
          `${redisUrl}/set/${encodeURIComponent(key)}/${encodeURIComponent(metaStr)}`,
          { headers: { Authorization: `Bearer ${redisToken}` } }
        );
      } else {
        // чтобы НЕ продлевать жизнь сессии — берём оставшийся TTL и ставим обратно с ним
        const tr = await fetch(`${redisUrl}/ttl/${encodeURIComponent(key)}`, {
          headers: { Authorization: `Bearer ${redisToken}` },
        });
        const td = await tr.json();
        const ttlLeft = Number(td?.result);

        if (Number.isFinite(ttlLeft) && ttlLeft > 0) {
          await fetch(
            `${redisUrl}/set/${encodeURIComponent(key)}/${encodeURIComponent(metaStr)}?EX=${ttlLeft}`,
            { headers: { Authorization: `Bearer ${redisToken}` } }
          );
        }
      }
    } catch {
      // meta не JSON -> просто не обновляем lastSeen
    }
  } catch {
    // Redis умер/сеть — лучше не пускать
    return Response.redirect(new URL("/bind.html", request.url), 302);
  }

  return context.next();
};
